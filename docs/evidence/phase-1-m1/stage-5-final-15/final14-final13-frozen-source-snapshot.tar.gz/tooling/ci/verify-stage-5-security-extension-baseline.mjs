import { execFileSync, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { lstat, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  STAGE5_FINAL9_REJECTED_TAG,
  STAGE5_FINAL9_REJECTED_TAG_TARGET,
  STAGE5_FINAL10_CI_EXECUTION_SHA256,
  STAGE5_FINAL10_CI_EXECUTION,
  STAGE5_FINAL10_CI_LOG_SHA256,
  STAGE5_FINAL10_CI_LOG,
  STAGE5_FINAL10_CORRECTION_MATRIX_SHA256,
  STAGE5_FINAL10_CORRECTION_MATRIX_PATH,
  STAGE5_FINAL10_INVOCATION_GUARD_SHA256,
  STAGE5_FINAL10_INVOCATION_GUARD_PATH,
  STAGE5_FINAL10_PHASE1_BASELINE_EXPECTED_PACKAGE_SHA256,
  STAGE5_FINAL10_PHASE1_BASELINE_SHA256,
  STAGE5_FINAL10_PHASE1_BASELINE_PATH,
  STAGE5_FINAL10_PRE_CI_EVIDENCE_INDEX_SHA256,
  STAGE5_FINAL10_PRE_CI_EVIDENCE_INDEX,
  STAGE5_FINAL10_REJECTED_TAG,
  STAGE5_FINAL10_REJECTED_TAG_TARGET,
  STAGE5_FINAL10_REJECTION_RECORD,
  STAGE5_FINAL10_REJECTION_RECORD_SHA256,
  STAGE5_FINAL11_SECURITY_BASELINE_SHA256,
  STAGE5_FINAL11_REJECTION_RECORD_SHA256,
  STAGE5_FINAL11_PRE_FORMAT_SNAPSHOT_SHA256,
  STAGE5_FINAL12_CI_EXECUTION_SHA256,
  STAGE5_FINAL12_CI_FAILED_INDEX_SHA256,
  STAGE5_FINAL12_CI_LOG_SHA256,
  STAGE5_FINAL12_CORRECTION_MATRIX_SHA256,
  STAGE5_FINAL12_EVIDENCE_DIRECTORY,
  STAGE5_FINAL12_INVOCATION_GUARD_SHA256,
  STAGE5_FINAL12_REJECTION_MATRIX_SHA256,
  STAGE5_FINAL12_REJECTION_RECORD_SHA256,
  STAGE5_FINAL12_SECURITY_BASELINE_SHA256,
} from "./stage-5-candidate-contract.mjs";

export const PHASE0_ACCEPTED_BASELINE_PATH = "docs/reviews/PHASE_0_ACCEPTED_BASELINE.md";
export const PHASE0_ACCEPTED_BASELINE_SHA256 =
  "bcec4e4cd4b2c4b85263c09c64a5452db306fcf68414947231b35d300f59b1fb";
export const PHASE0_ACCEPTED_BASELINE_ENTRY_COUNT = 40;
export const PHASE0_ACCEPTED_BASELINE_SOURCE_COMMIT = "32b7d2f0a8b628c5c368d22983c5d631aad520fb";
export const PHASE0_PERMISSIONS_PATH = "docs/PERMISSIONS.md";
export const PHASE0_PERMISSIONS_SHA256 =
  "ad036b8647f4482bc5e59bff09e5adbf653a4d3ed3994a20cd5b201d104ea1d9";

export const STAGE5_SECURITY_EXTENSION_BASELINE_PATH =
  "docs/reviews/phase-1-m1/STAGE_5_SECURITY_EXTENSION_BASELINE.json";
export const STAGE5_SECURITY_EXTENSION_DOCUMENT_PATH =
  "docs/implementation/M1_STAGE_5_SECURITY_EXTENSION.md";
export const STAGE5_SECURITY_EXTENSION_BASELINE_SHA256 =
  "2fb65b6fa0d14875f9c756496f75b2b9fed3a446409295f5bdff46e5deae70cb";
export const STAGE5_SECURITY_EXTENSION_BASELINE_ID =
  "phase-1-m1-stage-5-finance-cost-permission-v1";
export const STAGE5_SECURITY_EXTENSION_PROTECTED_PATHS = Object.freeze(
  [
    "apps/admin-api/src/m1-routes.ts",
    "apps/admin-api/test/m1-authorization-boundary.test.ts",
    "docs/PERMISSIONS.md",
    "docs/implementation/M1_STAGE_5_SECURITY_EXTENSION.md",
    "package.json",
    "packages/backend-core/src/agency-organization/agency-bootstrap.ts",
    "packages/backend-core/src/modules/trip-operations/application/m1-staff-operations.ts",
    "packages/backend-core/src/staff-access/permission-registry.ts",
    "packages/backend-core/test/agency-organization/agency-bootstrap.test.ts",
    "tooling/ci/verify.mjs",
  ].toSorted(),
);

const SHA256_PATTERN = /^[a-f0-9]{64}$/u;
const AGGREGATE_SERIALIZATION =
  "newline-terminated records: relative-path<TAB>bytes<TAB>sha256, sorted by relative path";
const REQUIRED_CI_SCRIPTS = Object.freeze({
  "stage5:security-extension:verify":
    "node tooling/ci/verify-stage-5-security-extension-baseline.mjs",
  "test:stage5-security-extension-baseline":
    "node tooling/ci/test-stage-5-security-extension-baseline.mjs && node tooling/ci/test-stage-5-final12-security-extension-baseline.mjs && node tooling/ci/test-stage-5-final13-security-extension-baseline.mjs",
  "test:stage5-source-scope":
    "node tooling/ci/test-stage-5-source-scope.mjs && node tooling/ci/test-stage-5-evidence-index.mjs && node tooling/ci/test-stage-5-finding-lineage.mjs && node tooling/ci/test-stage-5-final11-finding-lineage.mjs && node tooling/ci/test-stage-5-final12-finding-lineage.mjs && node tooling/ci/test-stage-5-final13-finding-lineage.mjs",
  "evidence:stage5:matrix": "node tooling/ci/stage-5-final13-finding-lineage.mjs --write",
  "evidence:stage5:baseline":
    "node tooling/ci/generate-stage-5-final13-security-extension-baseline.mjs --write",
  "evidence:stage5:prepare": "node tooling/ci/prepare-stage-5-final13-evidence.mjs",
  "evidence:stage5:preflight": "node tooling/ci/stage-5-final13-readiness-preflight.mjs --write",
  "evidence:stage5:ci": "node tooling/ci/run-stage-5-final13-authoritative-ci.mjs",
});
const REQUIRED_CI_GATES = Object.freeze([
  ["stage5-security-extension:pre", "stage5:security-extension:verify"],
  ["test:stage5-security-extension-baseline", "test:stage5-security-extension-baseline"],
  ["test:stage5-source-scope", "test:stage5-source-scope"],
  ["stage5-security-extension:post", "stage5:security-extension:verify"],
]);
const FINAL11_ALLOWED_PROTECTED_PATH_DELTAS = Object.freeze(
  ["docs/implementation/M1_STAGE_5_SECURITY_EXTENSION.md", "package.json"].toSorted(),
);
const FINAL12_ALLOWED_PROTECTED_PATH_DELTAS = Object.freeze(
  ["docs/implementation/M1_STAGE_5_SECURITY_EXTENSION.md", "package.json"].toSorted(),
);
const FINAL13_ALLOWED_PROTECTED_PATH_DELTAS = Object.freeze(
  ["docs/implementation/M1_STAGE_5_SECURITY_EXTENSION.md", "package.json"].toSorted(),
);
const FINAL10_FAILED_CI_PROVENANCE = Object.freeze({
  candidate: "FINAL-10",
  phase: "FINAL",
  status: "REJECTED",
  tag: STAGE5_FINAL10_REJECTED_TAG,
  target: STAGE5_FINAL10_REJECTED_TAG_TARGET,
  failedGate: "stage5-security-extension:pre",
  command: "corepack pnpm ci:verify",
  invocationCount: 1,
  result: "FAIL",
  exitCode: 1,
  ciLogSha256: STAGE5_FINAL10_CI_LOG_SHA256,
  ciExecutionSha256: STAGE5_FINAL10_CI_EXECUTION_SHA256,
  preCiEvidenceIndexSha256: STAGE5_FINAL10_PRE_CI_EVIDENCE_INDEX_SHA256,
  correctionMatrixSha256: STAGE5_FINAL10_CORRECTION_MATRIX_SHA256,
  rejectionRecordSha256: STAGE5_FINAL10_REJECTION_RECORD_SHA256,
  previousPhase1BaselineSha256: STAGE5_FINAL10_PHASE1_BASELINE_SHA256,
  staleBaselinePackageSha256: STAGE5_FINAL10_PHASE1_BASELINE_EXPECTED_PACKAGE_SHA256,
  localInvocationGuardSha256: STAGE5_FINAL10_INVOCATION_GUARD_SHA256,
  stage6Actions: 0,
});

const sha256 = (content) => createHash("sha256").update(content).digest("hex");
const sameArray = (left, right) =>
  left.length === right.length && left.every((value, index) => value === right[index]);
const assert = (condition, message) => {
  if (!condition) throw new Error(message);
};
const isSafeRelativePath = (value) =>
  typeof value === "string" &&
  value.length > 0 &&
  !path.isAbsolute(value) &&
  !value.split("/").some((segment) => segment === "" || segment === "." || segment === "..");
const serializeRows = (rows) =>
  rows.map((row) => `${row.path}\t${row.bytes}\t${row.sha256}\n`).join("");

const readRegularFile = async (root, relativePath, label) => {
  assert(isSafeRelativePath(relativePath), `${label} path is unsafe: ${String(relativePath)}`);
  const absolutePath = path.join(root, relativePath);
  let metadata;
  try {
    metadata = await lstat(absolutePath);
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      throw new Error(`${label} is missing: ${relativePath}`, { cause: error });
    }
    throw error;
  }
  if (!metadata.isFile() || metadata.isSymbolicLink()) {
    throw new Error(`${label} is not a regular non-symlink file: ${relativePath}`);
  }
  return readFile(absolutePath);
};

const readGitBlob = (root, tag, relativePath) =>
  execFileSync("git", ["show", `${tag}:${relativePath}`], {
    cwd: root,
    maxBuffer: 8 * 1024 * 1024,
  });

const gitCommitTarget = (root, tag) =>
  execFileSync("git", ["rev-parse", `${tag}^{commit}`], { cwd: root, encoding: "utf8" }).trim();

const verifyPredecessorPhase1Lineage = async ({ root, baseline }) => {
  assert(
    gitCommitTarget(root, STAGE5_FINAL9_REJECTED_TAG) === STAGE5_FINAL9_REJECTED_TAG_TARGET,
    "FINAL-11 predecessor rejected FINAL-9 tag target changed",
  );
  execFileSync("git", ["merge-base", "--is-ancestor", STAGE5_FINAL9_REJECTED_TAG_TARGET, "HEAD"], {
    cwd: root,
  });
  const predecessorBytes = readGitBlob(
    root,
    STAGE5_FINAL9_REJECTED_TAG,
    STAGE5_SECURITY_EXTENSION_BASELINE_PATH,
  );
  assert(
    sha256(predecessorBytes) === STAGE5_FINAL10_PHASE1_BASELINE_SHA256,
    "FINAL-11 predecessor Phase 1 baseline bytes changed in the FINAL-9 tag",
  );
  const predecessor = JSON.parse(predecessorBytes.toString("utf8"));
  assert(
    predecessor.result === "PASS" &&
      predecessor.protectedFiles?.length === 10 &&
      predecessor.aggregateSha256 ===
        "528b8d760fcc468021e7b8e2dfdd44e20430f17119a11162bb6f93f2754bc668" &&
      predecessor.protectedFiles.find((entry) => entry.path === "package.json")?.sha256 ===
        STAGE5_FINAL10_PHASE1_BASELINE_EXPECTED_PACKAGE_SHA256,
    "FINAL-9 tagged Phase 1 predecessor has invalid result, file count, aggregate, or package pin",
  );

  assert(
    gitCommitTarget(root, STAGE5_FINAL10_REJECTED_TAG) === STAGE5_FINAL10_REJECTED_TAG_TARGET,
    "FINAL-11 rejected FINAL-10 tag target changed",
  );
  execFileSync("git", ["merge-base", "--is-ancestor", STAGE5_FINAL10_REJECTED_TAG_TARGET, "HEAD"], {
    cwd: root,
  });
  const final10BaselineBytes = readGitBlob(
    root,
    STAGE5_FINAL10_REJECTED_TAG,
    STAGE5_FINAL10_PHASE1_BASELINE_PATH,
  );
  const final10PackageBytes = readGitBlob(root, STAGE5_FINAL10_REJECTED_TAG, "package.json");
  const ciLogBytes = readGitBlob(root, STAGE5_FINAL10_REJECTED_TAG, STAGE5_FINAL10_CI_LOG);
  const ciExecutionBytes = readGitBlob(
    root,
    STAGE5_FINAL10_REJECTED_TAG,
    STAGE5_FINAL10_CI_EXECUTION,
  );
  const preCiIndexBytes = readGitBlob(
    root,
    STAGE5_FINAL10_REJECTED_TAG,
    STAGE5_FINAL10_PRE_CI_EVIDENCE_INDEX,
  );
  const correctionMatrixBytes = readGitBlob(
    root,
    STAGE5_FINAL10_REJECTED_TAG,
    STAGE5_FINAL10_CORRECTION_MATRIX_PATH,
  );
  const rejectionRecordBytes = readGitBlob(
    root,
    STAGE5_FINAL10_REJECTED_TAG,
    STAGE5_FINAL10_REJECTION_RECORD,
  );
  const ciExecution = JSON.parse(ciExecutionBytes.toString("utf8"));
  const final10Manifest = JSON.parse(final10BaselineBytes.toString("utf8"));
  const taggedPackageSha256 = sha256(final10PackageBytes);
  assert(
    sha256(final10BaselineBytes) === STAGE5_FINAL10_PHASE1_BASELINE_SHA256 &&
      final10Manifest.protectedFiles?.find((entry) => entry.path === "package.json")?.sha256 ===
        STAGE5_FINAL10_PHASE1_BASELINE_EXPECTED_PACKAGE_SHA256 &&
      taggedPackageSha256 === baseline.lineage.rejectedFinal10Candidate.packageSha256AtCi &&
      taggedPackageSha256 !== STAGE5_FINAL10_PHASE1_BASELINE_EXPECTED_PACKAGE_SHA256 &&
      sha256(ciLogBytes) === STAGE5_FINAL10_CI_LOG_SHA256 &&
      sha256(ciExecutionBytes) === STAGE5_FINAL10_CI_EXECUTION_SHA256 &&
      sha256(preCiIndexBytes) === STAGE5_FINAL10_PRE_CI_EVIDENCE_INDEX_SHA256 &&
      sha256(correctionMatrixBytes) === STAGE5_FINAL10_CORRECTION_MATRIX_SHA256 &&
      sha256(rejectionRecordBytes) === STAGE5_FINAL10_REJECTION_RECORD_SHA256 &&
      ciExecution.candidate === "FINAL-10" &&
      ciExecution.phase === "FINAL" &&
      ciExecution.invocationCount === 1 &&
      ciExecution.command === "corepack pnpm ci:verify" &&
      ciExecution.result === "FAIL" &&
      ciExecution.exitCode === 1 &&
      ciExecution.logSha256 === STAGE5_FINAL10_CI_LOG_SHA256,
    "FINAL-10 rejected tag no longer matches its consumed pre-gate failure and stale package pin",
  );
  const trackedLocalGuard = execFileSync(
    "git",
    ["ls-files", "--", STAGE5_FINAL10_INVOCATION_GUARD_PATH],
    {
      cwd: root,
      encoding: "utf8",
    },
  ).trim();
  assert(trackedLocalGuard === "", "FINAL-10 once-only local guard must remain untracked");
  let localGuardBytes;
  try {
    localGuardBytes = await readRegularFile(
      root,
      STAGE5_FINAL10_INVOCATION_GUARD_PATH,
      "FINAL-10 local-only invocation guard",
    );
  } catch (error) {
    if (!(error instanceof Error) || !("cause" in error) || error.cause?.code !== "ENOENT") {
      throw error;
    }
  }
  if (localGuardBytes) {
    assert(
      sha256(localGuardBytes) === STAGE5_FINAL10_INVOCATION_GUARD_SHA256,
      "FINAL-10 local-only invocation guard changed",
    );
  }
  const final11BaselineBytes = await readRegularFile(
    root,
    `${STAGE5_FINAL12_EVIDENCE_DIRECTORY}/final11-security-extension-baseline.json`,
    "immutable FINAL-11 Phase 1 baseline copy",
  );
  assert(
    sha256(final11BaselineBytes) === STAGE5_FINAL11_SECURITY_BASELINE_SHA256,
    "FINAL-11 Phase 1 baseline copy changed",
  );
  const final11Baseline = JSON.parse(final11BaselineBytes.toString("utf8"));
  const final11Deltas = final11Baseline.lineage?.final11Generation?.protectedPathDeltas ?? [];
  assert(
    final11Baseline.result === "PASS" &&
      final11Baseline.lineage?.final11Generation?.candidate === "FINAL-11" &&
      final11Deltas.every(
        (delta) =>
          final11Baseline.protectedFiles.find((entry) => entry.path === delta.path)?.sha256 ===
          delta.currentSha256,
      ),
    "immutable FINAL-11 baseline does not preserve its own protected-file deltas",
  );
};

const phase0RowsFrom = (manifestBytes) => {
  const rows = manifestBytes
    .toString("utf8")
    .split(/\r?\n/u)
    .flatMap((line) => {
      if (!line.startsWith("|") || !line.endsWith("|")) return [];
      const cells = line
        .split("|")
        .slice(1, -1)
        .map((cell) => cell.trim().replace(/^`|`$/gu, ""));
      return cells.length === 2 && isSafeRelativePath(cells[0]) && SHA256_PATTERN.test(cells[1])
        ? [{ path: cells[0], sha256: cells[1] }]
        : [];
    });
  assert(
    rows.length === PHASE0_ACCEPTED_BASELINE_ENTRY_COUNT,
    "Phase 0 accepted baseline has an unexpected protected-entry count",
  );
  assert(
    new Set(rows.map((row) => row.path)).size === rows.length,
    "Phase 0 accepted baseline contains duplicate protected paths",
  );
  return rows;
};

export const verifyPhase0AcceptedBaselineBytes = async ({ root = process.cwd() } = {}) => {
  const manifestBytes = await readRegularFile(
    root,
    PHASE0_ACCEPTED_BASELINE_PATH,
    "Phase 0 accepted baseline manifest",
  );
  assert(
    sha256(manifestBytes) === PHASE0_ACCEPTED_BASELINE_SHA256,
    "Phase 0 accepted baseline manifest hash mismatch",
  );
  const rows = phase0RowsFrom(manifestBytes);
  const mismatches = [];
  for (const row of rows) {
    const bytes = await readRegularFile(root, row.path, "Phase 0 protected baseline file");
    const actualSha256 = sha256(bytes);
    if (actualSha256 !== row.sha256) {
      mismatches.push({ path: row.path, expectedSha256: row.sha256, actualSha256 });
    }
  }
  assert(
    mismatches.length === 0,
    `Phase 0 protected baseline hash mismatch: ${mismatches.map((entry) => entry.path).join(", ")}`,
  );
  const permissions = await readRegularFile(
    root,
    PHASE0_PERMISSIONS_PATH,
    "Phase 0 permissions document",
  );
  assert(
    sha256(permissions) === PHASE0_PERMISSIONS_SHA256,
    "Phase 0 permissions document does not match its accepted protected hash",
  );
  return {
    result: "PASS",
    manifest: {
      path: PHASE0_ACCEPTED_BASELINE_PATH,
      sha256: sha256(manifestBytes),
      entryCount: rows.length,
    },
    permissions: { path: PHASE0_PERMISSIONS_PATH, sha256: sha256(permissions) },
  };
};

const gitText = (root, args) =>
  execFileSync("git", args, {
    cwd: root,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
  }).trim();

export const verifyPhase0AcceptedBaselineLineage = async ({ root = process.cwd() } = {}) => {
  const bytes = await verifyPhase0AcceptedBaselineBytes({ root });
  assert(
    gitText(root, ["cat-file", "-t", PHASE0_ACCEPTED_BASELINE_SOURCE_COMMIT]) === "commit",
    "Phase 0 accepted baseline source commit is unavailable or not a commit",
  );
  const ancestry = spawnSync(
    "git",
    ["merge-base", "--is-ancestor", PHASE0_ACCEPTED_BASELINE_SOURCE_COMMIT, "HEAD"],
    { cwd: root, stdio: "ignore" },
  );
  assert(
    ancestry.status === 0,
    "Phase 0 accepted baseline source commit is not an ancestor of the active candidate",
  );
  const sourceManifest = execFileSync(
    "git",
    ["show", `${PHASE0_ACCEPTED_BASELINE_SOURCE_COMMIT}:${PHASE0_ACCEPTED_BASELINE_PATH}`],
    { cwd: root, maxBuffer: 5 * 1024 * 1024 },
  );
  const currentManifest = await readRegularFile(
    root,
    PHASE0_ACCEPTED_BASELINE_PATH,
    "Phase 0 accepted baseline manifest",
  );
  assert(
    currentManifest.equals(sourceManifest),
    "Phase 0 accepted baseline manifest differs from its recorded source commit",
  );
  const sourcePermissions = execFileSync(
    "git",
    ["show", `${PHASE0_ACCEPTED_BASELINE_SOURCE_COMMIT}:${PHASE0_PERMISSIONS_PATH}`],
    { cwd: root, maxBuffer: 5 * 1024 * 1024 },
  );
  const currentPermissions = await readRegularFile(
    root,
    PHASE0_PERMISSIONS_PATH,
    "Phase 0 permissions document",
  );
  assert(
    currentPermissions.equals(sourcePermissions),
    "Phase 0 permissions document differs from its recorded source commit",
  );
  return {
    ...bytes,
    sourceCommit: PHASE0_ACCEPTED_BASELINE_SOURCE_COMMIT,
    sourceCommitIsAncestor: true,
    result: "PASS",
  };
};

const assertExtensionManifestShape = (baseline) => {
  assert(
    typeof baseline === "object" && baseline !== null && !Array.isArray(baseline),
    "Phase 1 extension baseline is not an object",
  );
  assert(baseline.schemaVersion === 1, "Phase 1 extension baseline schema version is invalid");
  assert(baseline.result === "PASS", "Phase 1 extension baseline result is not PASS");
  assert(
    baseline.baselineId === STAGE5_SECURITY_EXTENSION_BASELINE_ID,
    "Phase 1 extension baseline identity is invalid",
  );
  assert(baseline.stage === "PHASE_1_M1_STAGE_5", "Phase 1 extension baseline stage is invalid");
  assert(
    baseline.stage6Actions === 0,
    "Phase 1 extension baseline must not authorize Stage 6 actions",
  );

  const lineage = baseline.lineage;
  assert(
    typeof lineage === "object" && lineage !== null && !Array.isArray(lineage),
    "Phase 1 extension lineage is invalid",
  );
  assert(
    JSON.stringify(lineage.phase0AcceptedBaseline) ===
      JSON.stringify({
        path: PHASE0_ACCEPTED_BASELINE_PATH,
        sha256: PHASE0_ACCEPTED_BASELINE_SHA256,
        sourceCommit: PHASE0_ACCEPTED_BASELINE_SOURCE_COMMIT,
        entryCount: PHASE0_ACCEPTED_BASELINE_ENTRY_COUNT,
      }),
    "Phase 1 extension does not retain the exact Phase 0 baseline lineage",
  );
  assert(
    JSON.stringify(lineage.phase0Permissions) ===
      JSON.stringify({ path: PHASE0_PERMISSIONS_PATH, sha256: PHASE0_PERMISSIONS_SHA256 }),
    "Phase 1 extension does not retain the exact Phase 0 permissions lineage",
  );
  assert(
    typeof lineage.extensionDocument === "object" &&
      lineage.extensionDocument !== null &&
      lineage.extensionDocument.path === STAGE5_SECURITY_EXTENSION_DOCUMENT_PATH &&
      SHA256_PATTERN.test(lineage.extensionDocument.sha256),
    "Phase 1 extension documentation lineage is invalid",
  );
  assert(
    JSON.stringify(lineage.predecessorPhase1ExtensionBaseline) ===
      JSON.stringify({
        path: STAGE5_SECURITY_EXTENSION_BASELINE_PATH,
        sha256: STAGE5_FINAL10_PHASE1_BASELINE_SHA256,
        tag: STAGE5_FINAL9_REJECTED_TAG,
        target: STAGE5_FINAL9_REJECTED_TAG_TARGET,
        verificationResult: "PASS",
        protectedFileCount: 10,
        aggregateSha256: "528b8d760fcc468021e7b8e2dfdd44e20430f17119a11162bb6f93f2754bc668",
      }),
    "FINAL-11 extension baseline does not supersede the exact verified Phase 1 predecessor",
  );
  const final10 = lineage.rejectedFinal10Candidate;
  assert(
    typeof final10 === "object" &&
      final10 !== null &&
      final10.candidate === FINAL10_FAILED_CI_PROVENANCE.candidate &&
      final10.phase === FINAL10_FAILED_CI_PROVENANCE.phase &&
      final10.status === FINAL10_FAILED_CI_PROVENANCE.status &&
      final10.tag === FINAL10_FAILED_CI_PROVENANCE.tag &&
      final10.target === FINAL10_FAILED_CI_PROVENANCE.target &&
      final10.failedGate === FINAL10_FAILED_CI_PROVENANCE.failedGate &&
      final10.command === FINAL10_FAILED_CI_PROVENANCE.command &&
      final10.invocationCount === FINAL10_FAILED_CI_PROVENANCE.invocationCount &&
      final10.result === FINAL10_FAILED_CI_PROVENANCE.result &&
      final10.exitCode === FINAL10_FAILED_CI_PROVENANCE.exitCode &&
      final10.ciLogSha256 === FINAL10_FAILED_CI_PROVENANCE.ciLogSha256 &&
      final10.ciExecutionSha256 === FINAL10_FAILED_CI_PROVENANCE.ciExecutionSha256 &&
      final10.preCiEvidenceIndexSha256 === FINAL10_FAILED_CI_PROVENANCE.preCiEvidenceIndexSha256 &&
      final10.correctionMatrixSha256 === FINAL10_FAILED_CI_PROVENANCE.correctionMatrixSha256 &&
      final10.rejectionRecordSha256 === FINAL10_FAILED_CI_PROVENANCE.rejectionRecordSha256 &&
      final10.previousPhase1BaselineSha256 ===
        FINAL10_FAILED_CI_PROVENANCE.previousPhase1BaselineSha256 &&
      final10.staleBaselinePackageSha256 ===
        FINAL10_FAILED_CI_PROVENANCE.staleBaselinePackageSha256 &&
      SHA256_PATTERN.test(final10.packageSha256AtCi) &&
      final10.packageSha256AtCi !== final10.staleBaselinePackageSha256 &&
      final10.localInvocationGuardSha256 ===
        FINAL10_FAILED_CI_PROVENANCE.localInvocationGuardSha256 &&
      final10.stage6Actions === 0,
    "FINAL-11 extension baseline omits or alters the exact rejected FINAL-10 CI record",
  );
  const final11Generation = lineage.final11Generation;
  const pathDeltas = Array.isArray(final11Generation?.protectedPathDeltas)
    ? final11Generation.protectedPathDeltas
    : [];
  assert(
    final11Generation?.candidate === "FINAL-11" &&
      final11Generation.stage6Actions === 0 &&
      sameArray(
        pathDeltas.map((entry) => entry?.path),
        FINAL11_ALLOWED_PROTECTED_PATH_DELTAS,
      ) &&
      pathDeltas.every(
        (entry) =>
          SHA256_PATTERN.test(entry?.previousSha256) &&
          SHA256_PATTERN.test(entry?.currentSha256) &&
          entry.previousSha256 !== entry.currentSha256,
      ),
    "FINAL-11 extension baseline has an unexpected protected-file delta or Stage 6 action",
  );

  const final12Generation = lineage.final12Generation;
  const final12Deltas = Array.isArray(final12Generation?.protectedPathDeltas)
    ? final12Generation.protectedPathDeltas
    : [];
  assert(
    final12Generation?.candidate === "FINAL-12" &&
      final12Generation.previousBaselineSha256 === STAGE5_FINAL11_SECURITY_BASELINE_SHA256 &&
      final12Generation.stage6Actions === 0 &&
      sameArray(
        final12Deltas.map((entry) => entry?.path),
        FINAL12_ALLOWED_PROTECTED_PATH_DELTAS,
      ) &&
      final12Deltas.every(
        (entry) =>
          SHA256_PATTERN.test(entry?.previousSha256) &&
          SHA256_PATTERN.test(entry?.currentSha256) &&
          entry.previousSha256 !== entry.currentSha256,
      ),
    "FINAL-12 extension baseline has an unexpected protected-file delta or Stage 6 action",
  );
  const rejectedFinal11 = lineage.rejectedFinal11Candidate;
  assert(
    rejectedFinal11?.candidate === "FINAL-11" &&
      rejectedFinal11.status === "REJECTED / CI CONSUMED / FORMAT-GATE FAILURE" &&
      rejectedFinal11.failedGate === "format:check" &&
      rejectedFinal11.invocationCount === 1 &&
      rejectedFinal11.exitCode === 1 &&
      rejectedFinal11.ciLogSha256 ===
        "6e686ec0cf07bee47a155a5fc167f8ad9e55caa9ac2bb9564b755e90745db109" &&
      rejectedFinal11.ciExecutionSha256 ===
        "cfca7be8cb139bd32e4b43e6f7fb847b01b2042a217cec686b3234906a6d2cce" &&
      rejectedFinal11.ciFailedIndexSha256 ===
        "620c4019206ffa97e8456cdb8e6fb3689d27ab1ae86720db5ccabb7e7269b46a" &&
      rejectedFinal11.invocationGuardSha256 ===
        "15a3d5fac1a61e1b354c88a53ca870a0a22d898a06c398622f908738bdf2f473" &&
      rejectedFinal11.rejectionRecordSha256 === STAGE5_FINAL11_REJECTION_RECORD_SHA256 &&
      rejectedFinal11.preFormatSnapshotSha256 === STAGE5_FINAL11_PRE_FORMAT_SNAPSHOT_SHA256 &&
      rejectedFinal11.previousBaselineSha256 === STAGE5_FINAL11_SECURITY_BASELINE_SHA256 &&
      rejectedFinal11.stage6Actions === 0,
    "FINAL-12 baseline must preserve the exact consumed FINAL-11 rejection lineage",
  );
  const final13Generation = lineage.final13Generation;
  const final13Deltas = Array.isArray(final13Generation?.protectedPathDeltas)
    ? final13Generation.protectedPathDeltas
    : [];
  assert(
    final13Generation?.candidate === "FINAL-13" &&
      final13Generation.previousBaselineSha256 === STAGE5_FINAL12_SECURITY_BASELINE_SHA256 &&
      final13Generation.stage6Actions === 0 &&
      sameArray(
        final13Deltas.map((entry) => entry?.path),
        FINAL13_ALLOWED_PROTECTED_PATH_DELTAS,
      ) &&
      final13Deltas.every(
        (entry) =>
          SHA256_PATTERN.test(entry?.previousSha256) &&
          SHA256_PATTERN.test(entry?.currentSha256) &&
          entry.previousSha256 !== entry.currentSha256,
      ),
    "FINAL-13 extension baseline has an unexpected protected-file delta or Stage 6 action",
  );
  const rejectedFinal12 = lineage.rejectedFinal12Candidate;
  assert(
    rejectedFinal12?.candidate === "FINAL-12" &&
      rejectedFinal12.status === "REJECTED / CI CONSUMED / LINT-GATE FAILURE" &&
      rejectedFinal12.failedGate === "lint" &&
      rejectedFinal12.invocationCount === 1 &&
      rejectedFinal12.exitCode === 1 &&
      rejectedFinal12.ciLogSha256 === STAGE5_FINAL12_CI_LOG_SHA256 &&
      rejectedFinal12.ciExecutionSha256 === STAGE5_FINAL12_CI_EXECUTION_SHA256 &&
      rejectedFinal12.ciFailedIndexSha256 === STAGE5_FINAL12_CI_FAILED_INDEX_SHA256 &&
      rejectedFinal12.invocationGuardSha256 === STAGE5_FINAL12_INVOCATION_GUARD_SHA256 &&
      rejectedFinal12.rejectionRecordSha256 === STAGE5_FINAL12_REJECTION_RECORD_SHA256 &&
      rejectedFinal12.rejectionMatrixSha256 === STAGE5_FINAL12_REJECTION_MATRIX_SHA256 &&
      rejectedFinal12.correctionMatrixSha256 === STAGE5_FINAL12_CORRECTION_MATRIX_SHA256 &&
      rejectedFinal12.previousBaselineSha256 === STAGE5_FINAL12_SECURITY_BASELINE_SHA256 &&
      rejectedFinal12.stage6Actions === 0,
    "FINAL-13 baseline must preserve the exact consumed FINAL-12 rejection lineage",
  );

  const extension = baseline.extension;
  assert(
    typeof extension === "object" && extension !== null && !Array.isArray(extension),
    "Phase 1 extension declaration is invalid",
  );
  assert(
    extension.permissionId === "finance.manage_costs" &&
      extension.permissionRegistryVersion === 2 &&
      sameArray(extension.allowedScopeKinds ?? [], ["AGENCY"]) &&
      sameArray(extension.allowedAccessLevels ?? [], ["ALL"]) &&
      extension.ownerRoleReceivesPermission === true &&
      extension.portalEligible === false &&
      extension.stage6Actions === 0,
    "Phase 1 finance-cost permission declaration is invalid",
  );
  assert(
    sameArray(extension.doesNotGrant ?? [], [
      "finance.manage_payments",
      "finance.view_margins",
      "finance.view_prices",
      "portal.access",
    ]),
    "Phase 1 finance-cost permission separation-of-duties declaration is invalid",
  );

  assert(Array.isArray(baseline.protectedFiles), "Phase 1 extension protected files are invalid");
  const paths = baseline.protectedFiles.map((entry) => entry?.path);
  assert(
    sameArray(paths, STAGE5_SECURITY_EXTENSION_PROTECTED_PATHS),
    "Phase 1 extension protected-file path set is invalid",
  );
  for (const entry of baseline.protectedFiles) {
    assert(
      typeof entry === "object" &&
        entry !== null &&
        isSafeRelativePath(entry.path) &&
        Number.isSafeInteger(entry.bytes) &&
        entry.bytes > 0 &&
        SHA256_PATTERN.test(entry.sha256),
      "Phase 1 extension protected-file row is invalid",
    );
  }
  assert(
    baseline.aggregateSerialization === AGGREGATE_SERIALIZATION &&
      SHA256_PATTERN.test(baseline.aggregateSha256),
    "Phase 1 extension aggregate declaration is invalid",
  );
  const extensionDocumentRow = baseline.protectedFiles.find(
    (entry) => entry.path === STAGE5_SECURITY_EXTENSION_DOCUMENT_PATH,
  );
  assert(
    extensionDocumentRow?.sha256 === lineage.extensionDocument.sha256,
    "Phase 1 extension documentation hash is not bound to the protected-file manifest",
  );
  for (const delta of final13Deltas) {
    const currentRow = baseline.protectedFiles.find((entry) => entry.path === delta.path);
    assert(
      currentRow?.sha256 === delta.currentSha256,
      `FINAL-13 protected-file delta is not bound to the active manifest: ${delta.path}`,
    );
  }
};

const verifyExtensionSemantics = async ({ root, protectedBytes }) => {
  const documentation = protectedBytes
    .get(STAGE5_SECURITY_EXTENSION_DOCUMENT_PATH)
    ?.toString("utf8");
  const registry = protectedBytes
    .get("packages/backend-core/src/staff-access/permission-registry.ts")
    ?.toString("utf8")
    .replace(/\s+/gu, " ");
  const bootstrap = protectedBytes
    .get("packages/backend-core/src/agency-organization/agency-bootstrap.ts")
    ?.toString("utf8")
    .replace(/\s+/gu, " ");
  const operations = protectedBytes
    .get("packages/backend-core/src/modules/trip-operations/application/m1-staff-operations.ts")
    ?.toString("utf8")
    .replace(/\s+/gu, " ");
  const routes = protectedBytes.get("apps/admin-api/src/m1-routes.ts")?.toString("utf8");
  const packageManifest = JSON.parse(protectedBytes.get("package.json")?.toString("utf8") ?? "");
  const verifySource = protectedBytes.get("tooling/ci/verify.mjs")?.toString("utf8") ?? "";
  const final11Runner = (
    await readRegularFile(
      root,
      "tooling/ci/run-stage-5-final11-authoritative-ci.mjs",
      "FINAL-11 authoritative CI runner",
    )
  ).toString("utf8");
  const final12Runner = (
    await readRegularFile(
      root,
      "tooling/ci/run-stage-5-final12-authoritative-ci.mjs",
      "FINAL-12 authoritative CI runner",
    )
  ).toString("utf8");
  const final13Runner = (
    await readRegularFile(
      root,
      "tooling/ci/run-stage-5-final13-authoritative-ci.mjs",
      "FINAL-13 authoritative CI runner",
    )
  ).toString("utf8");
  const final10Runner = (
    await readRegularFile(
      root,
      "tooling/ci/run-stage-5-final10-authoritative-ci.mjs",
      "consumed FINAL-10 authoritative CI runner protection stub",
    )
  ).toString("utf8");

  assert(
    documentation?.includes("`finance.manage_costs`") &&
      documentation.includes("`AGENCY`") &&
      documentation.includes("`ALL`") &&
      documentation.includes("does **not** grant price visibility") &&
      documentation.includes("`finance.view_costs`") &&
      documentation.includes("For FINAL-11") &&
      documentation.includes("For FINAL-12") &&
      documentation.includes("For FINAL-13") &&
      documentation.includes("FINAL-10") &&
      documentation.includes("only approved content deltas"),
    "Phase 1 extension documentation no longer states the bounded capability semantics",
  );
  assert(
    registry?.includes("export const PERMISSION_REGISTRY_VERSION = 2 as const;") &&
      /id: "finance[.]manage_costs", allowedScopeKinds: \["AGENCY"\], allowedAccessLevels: \["ALL"\]/u.test(
        registry,
      ),
    "Code-owned registry no longer defines finance.manage_costs as AGENCY/ALL in version 2",
  );
  assert(
    bootstrap?.includes("permissionIds: OWNER_ROLE_PERMISSION_IDS") &&
      registry.includes(
        "export const OWNER_ROLE_PERMISSION_IDS: readonly StaffPermissionId[] = STAGE_5_PERMISSION_REGISTRY.map",
      ),
    "Bootstrap owner template is no longer bound to the complete code-owned registry",
  );
  assert(
    operations?.includes('"finance.manage_costs"') &&
      operations.includes(
        "return dependencies.repository.createM1TripSlice(normalizedInput, authorization)",
      ) &&
      operations.includes(
        "return dependencies.repository.updateInternalSupplierNote(normalizedInput, authorization)",
      ),
    "M1 Staff operations no longer authorize restricted supplier-cost command paths",
  );
  assert(
    routes?.includes("m1Operations: M1StaffTripOperations") &&
      !routes.includes("createM1OperationalSliceRepository"),
    "Admin route boundary no longer consumes the authorization-enforcing M1 facade",
  );
  assert(
    typeof packageManifest.scripts === "object" && packageManifest.scripts !== null,
    "Package scripts are invalid",
  );
  for (const [name, command] of Object.entries(REQUIRED_CI_SCRIPTS)) {
    assert(
      packageManifest.scripts[name] === command,
      `Phase 1 extension CI script is missing or changed: ${name}`,
    );
  }
  for (const [label, script] of REQUIRED_CI_GATES) {
    assert(
      verifySource.includes(`["${label}", "${script}"]`),
      `Phase 1 extension CI gate is missing or changed: ${label}`,
    );
  }
  const gatePositions = REQUIRED_CI_GATES.map(([label, script]) =>
    verifySource.indexOf(`["${label}", "${script}"]`),
  );
  assert(
    gatePositions.every(
      (position, index) => position >= 0 && (index === 0 || position > gatePositions[index - 1]),
    ),
    "Phase 1 extension gates must run protected pre-check, baseline/source-scope tests, then post-check",
  );
  assert(
    final11Runner.includes('"FINAL-11"') &&
      final11Runner.includes("STAGE5_FINAL11_CI_VERIFY_INVOCATION_GUARD") &&
      final11Runner.includes("const guardPath") &&
      final11Runner.includes("corepack") &&
      final11Runner.includes("ci:verify") &&
      final11Runner.includes("verifyStage5Final11ReadinessPreflight"),
    "FINAL-11 authoritative runner no longer binds its readiness receipt and once-only CI guard",
  );
  assert(
    final12Runner.includes('"FINAL-12"') &&
      final12Runner.includes("STAGE5_FINAL12_CI_VERIFY_INVOCATION_GUARD") &&
      final12Runner.includes("const guardPath") &&
      final12Runner.includes("corepack") &&
      final12Runner.includes("ci:verify") &&
      final12Runner.includes("verifyStage5Final12Readiness"),
    "FINAL-12 runner must bind its readiness receipt and fresh once-only CI guard",
  );
  assert(
    final13Runner.includes('"FINAL-13"') &&
      final13Runner.includes("STAGE5_FINAL13_CI_VERIFY_INVOCATION_GUARD") &&
      final13Runner.includes("const guardPath") &&
      final13Runner.includes("corepack") &&
      final13Runner.includes("ci:verify") &&
      final13Runner.includes("verifyStage5Final13Readiness"),
    "FINAL-13 runner must bind its readiness receipt and fresh once-only CI guard",
  );
  assert(
    final10Runner.includes("FINAL-10 runner is disabled") &&
      !final10Runner.includes("spawnSync(") &&
      !final10Runner.includes("execFileSync("),
    "Consumed FINAL-10 runner must remain a non-runnable protection stub",
  );
  return {
    result: "PASS",
    ciScripts: Object.keys(REQUIRED_CI_SCRIPTS),
    ciGates: REQUIRED_CI_GATES.map(([label]) => label),
  };
};

export const verifyStage5SecurityExtensionBaseline = async ({
  root = process.cwd(),
  expectedBaselineSha256 = STAGE5_SECURITY_EXTENSION_BASELINE_SHA256,
} = {}) => {
  assert(
    SHA256_PATTERN.test(expectedBaselineSha256),
    "Phase 1 extension baseline verifier has no pinned baseline SHA-256",
  );
  const phase0 = await verifyPhase0AcceptedBaselineLineage({ root });
  const baselineBytes = await readRegularFile(
    root,
    STAGE5_SECURITY_EXTENSION_BASELINE_PATH,
    "Phase 1 extension baseline manifest",
  );
  assert(
    sha256(baselineBytes) === expectedBaselineSha256,
    "Phase 1 extension baseline manifest does not match its pinned SHA-256",
  );
  let baseline;
  try {
    baseline = JSON.parse(baselineBytes.toString("utf8"));
  } catch {
    throw new Error("Phase 1 extension baseline manifest is not valid JSON");
  }
  assertExtensionManifestShape(baseline);
  await verifyPredecessorPhase1Lineage({ root, baseline });

  const protectedBytes = new Map();
  const mismatches = [];
  for (const entry of baseline.protectedFiles) {
    const bytes = await readRegularFile(root, entry.path, "Phase 1 extension protected file");
    protectedBytes.set(entry.path, bytes);
    const actualSha256 = sha256(bytes);
    if (bytes.length !== entry.bytes || actualSha256 !== entry.sha256) {
      mismatches.push({
        path: entry.path,
        expectedBytes: entry.bytes,
        actualBytes: bytes.length,
        expectedSha256: entry.sha256,
        actualSha256,
      });
    }
  }
  assert(
    mismatches.length === 0,
    `Phase 1 security extension protected-file mismatch: ${mismatches.map((entry) => entry.path).join(", ")}`,
  );
  assert(
    sha256(serializeRows(baseline.protectedFiles)) === baseline.aggregateSha256,
    "Phase 1 extension protected-file aggregate hash mismatch",
  );
  const semantics = await verifyExtensionSemantics({ root, protectedBytes });
  return {
    schemaVersion: 1,
    result: "PASS",
    phase0,
    phase1: {
      baselinePath: STAGE5_SECURITY_EXTENSION_BASELINE_PATH,
      baselineSha256: sha256(baselineBytes),
      protectedFileCount: baseline.protectedFiles.length,
      aggregateSha256: baseline.aggregateSha256,
      extension: baseline.extension,
    },
    semantics,
  };
};

const isDirectExecution =
  process.argv[1] !== undefined && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectExecution) {
  console.log(JSON.stringify(await verifyStage5SecurityExtensionBaseline(), null, 2));
}
