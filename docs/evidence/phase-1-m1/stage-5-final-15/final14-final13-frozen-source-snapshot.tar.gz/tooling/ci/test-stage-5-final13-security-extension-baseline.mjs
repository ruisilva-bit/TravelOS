import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, URL } from "node:url";
import {
  STAGE5_FINAL12_SECURITY_BASELINE_SHA256,
  STAGE5_FINAL13_EVIDENCE_DIRECTORY,
} from "./stage-5-candidate-contract.mjs";
import { buildStage5Final13SecurityExtensionBaseline } from "./generate-stage-5-final13-security-extension-baseline.mjs";
import { verifyStage5Final13FindingLineage } from "./stage-5-final13-finding-lineage.mjs";
import {
  STAGE5_SECURITY_EXTENSION_BASELINE_PATH,
  STAGE5_SECURITY_EXTENSION_DOCUMENT_PATH,
  STAGE5_SECURITY_EXTENSION_PROTECTED_PATHS,
  verifyStage5SecurityExtensionBaseline,
} from "./verify-stage-5-security-extension-baseline.mjs";

const root = path.resolve(fileURLToPath(new URL("../..", import.meta.url)));
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");
const activeBytes = await readFile(path.join(root, STAGE5_SECURITY_EXTENSION_BASELINE_PATH));
const active = JSON.parse(activeBytes.toString("utf8"));
const previousBytes = await readFile(
  path.join(root, STAGE5_FINAL13_EVIDENCE_DIRECTORY, "final12-security-extension-baseline.json"),
);
assert.equal(sha256(previousBytes), STAGE5_FINAL12_SECURITY_BASELINE_SHA256);
const previous = JSON.parse(previousBytes.toString("utf8"));
const lineage = await verifyStage5Final13FindingLineage({ root });
const currentFiles = await Promise.all(
  STAGE5_SECURITY_EXTENSION_PROTECTED_PATHS.map(async (protectedPath) => ({
    path: protectedPath,
    bytes: await readFile(path.join(root, protectedPath)),
  })),
);
const rebuilt = buildStage5Final13SecurityExtensionBaseline({
  previousBaseline: previous,
  currentFiles,
  lineage,
});
assert.deepEqual(
  active,
  rebuilt,
  "active baseline must be deterministic from the immutable FINAL-12 baseline and exact FINAL-13 deltas",
);
assert.deepEqual(
  active.lineage.final13Generation.protectedPathDeltas.map((delta) => delta.path).toSorted(),
  [STAGE5_SECURITY_EXTENSION_DOCUMENT_PATH, "package.json"].toSorted(),
);
assert.equal(
  active.lineage.final13Generation.previousBaselineSha256,
  STAGE5_FINAL12_SECURITY_BASELINE_SHA256,
);
assert.equal(active.lineage.rejectedFinal12Candidate.ciLogSha256, lineage.ciLog.sha256);
assert.equal(active.lineage.rejectedFinal12Candidate.stage6Actions, 0);
const packageRow = active.protectedFiles.find((entry) => entry.path === "package.json");
assert.equal(packageRow.sha256, sha256(await readFile(path.join(root, "package.json"))));
const verification = await verifyStage5SecurityExtensionBaseline({
  root,
  expectedBaselineSha256: sha256(activeBytes),
});
assert.equal(verification.result, "PASS");
assert.throws(() =>
  buildStage5Final13SecurityExtensionBaseline({
    previousBaseline: previous,
    currentFiles: [...currentFiles, { path: "unauthorized-drift", bytes: Buffer.from("x") }],
    lineage,
  }),
);
assert.throws(() =>
  buildStage5Final13SecurityExtensionBaseline({
    previousBaseline: previous,
    currentFiles: currentFiles.slice(1),
    lineage,
  }),
);
process.stdout.write(
  `${JSON.stringify(
    {
      result: "PASS",
      candidate: "FINAL-13",
      protectedPaths: currentFiles.length,
      permittedDeltas: active.lineage.final13Generation.protectedPathDeltas.map(
        (delta) => delta.path,
      ),
      baselineSha256: sha256(activeBytes),
      stage6Actions: 0,
    },
    null,
    2,
  )}\n`,
);
